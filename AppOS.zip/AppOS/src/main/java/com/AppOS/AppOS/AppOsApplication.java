package com.AppOS.AppOS;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AppOsApplication {

	public static void main(String[] args) {
		SpringApplication.run(AppOsApplication.class, args);
	}

}
