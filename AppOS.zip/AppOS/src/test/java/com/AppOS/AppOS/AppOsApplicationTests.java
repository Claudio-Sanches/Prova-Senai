package com.AppOS.AppOS;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AppOsApplicationTests {

	@Test
	void contextLoads() {
	}

}
